class Item {
  String? item_type;
  String? item_name;
  String? item_unit;
  double? item_price;

  Item(this.item_type,this.item_name,this.item_unit,this.item_price);
}