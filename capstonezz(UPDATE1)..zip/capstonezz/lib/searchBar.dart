import 'package:capstonezz/dummyItems.dart';
import 'package:flutter/material.dart';

class Searchbar extends StatefulWidget {
  const Searchbar({super.key});

  @override
  State<Searchbar> createState() => _SearchbarState();
}

class _SearchbarState extends State<Searchbar> {

  static List<Item> item_list = [
    Item("Distilled Water", "SM Bonus", "325ml", 6.00),
    Item("Distilled Water", "Wilkins", "330ml", 12.00),
    Item("Purified Water", "Nature Spring", "500ml", 9.90),
    Item("Purified Water", "Magnolia Pure", "355ml", 8.80),
    Item("Mineralized Water", "Summit", "350ml", 11.00),
    Item("Mineralized Water", "Refresh", "500ml", 8.25),
    Item("Bread", "Pinoy Pandesal", "250g", 25.00),
    Item("Bread", "Pinoy Tasty", "450g", 40.50),
    Item("Powdered Milk", "Bear Brand", "135g", 50.00),
    Item("Powdered Milk", "Birch Tree Full Cream", "150g", 64.75),
    Item("Coffee Refill", "Nescafe Classic", "23g", 20.00),
    Item("Coffee Refill", "Great Taste (Granules)", "25g", 21.00),


  ];

  List<Item> display_list = List.from(item_list);

  void updateList(String value) {
    setState(() {
      display_list = item_list.where((element) =>
      element.item_type!.toLowerCase().contains(value.toLowerCase()) ||
          element.item_name!.toLowerCase().contains(value.toLowerCase())
      ).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
       color: Color(0xFFB1E8DE),
        child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Enter item to search", style: TextStyle(
              color: Colors.teal.shade900,
              fontSize: 22.0,
              fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20),
            TextField(
              onChanged: (value) => updateList(value),
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9.0),
                  borderSide: BorderSide.none,
                ),
                  hintText:"eg: Canned Sardines",
                prefixIcon: Icon(Icons.search),
              ),
            ),
            SizedBox(height: 20),
            Expanded(child: display_list.length == 0? Center (child: Text("No Result Found", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),),):
            ListView.builder(
                itemCount: display_list.length,
                itemBuilder: (context, index)=> ListTile(
                  title: Text(display_list[index].item_name!, style: TextStyle(
                    fontWeight: FontWeight.bold,),
                  ),
                  subtitle: Text('${display_list[index].item_unit!}', style: TextStyle(color: Colors.teal.shade900,),),
                  trailing: Text(
                    "₱${display_list[index].item_price}", style: TextStyle(
                    color: Colors.teal.shade900,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,),
                  ),
                ),
              ),
            ),
          ]
        ),
      ),
      ),
    );
  }
}
